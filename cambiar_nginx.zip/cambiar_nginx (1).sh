#!/bin/bash

# Este script detiene, deshabilita y enmascara OpenResty,
# y luego desenmascara, habilita e inicia Nginx.

# Asegúrate de ejecutar este script con 'sudo' o como root.

echo "Iniciando la transición de OpenResty a Nginx..."

# --- Gestión de OpenResty ---
echo "1. Deteniendo OpenResty..."
sudo systemctl stop openresty

echo "2. Deshabilitando OpenResty para que no se inicie en el arranque..."
sudo systemctl disable openresty

echo "3. Enmascarando Openresty para evitar que se inicie accidentalmente..."
sudo systemctl mask openresty

# --- Gestión de Nginx ---
echo "4. Desenmascarando Nginx (si estaba enmascarado)..."
sudo systemctl unmask nginx

echo "5. Habilitando Nginx para que se inicie en el arranque..."
# Tienes dos comandos 'enable nginx' en tu lista; solo necesitamos uno.
sudo systemctl enable nginx

echo "6. Iniciando Nginx..."
sudo systemctl start nginx

echo "Proceso completado. El estado de Nginx es:"
sudo systemctl status nginx | grep Active

echo "El estado de OpenResty es:"
sudo systemctl status openresty | grep Active
