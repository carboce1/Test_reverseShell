-- session_manager.lua
-- Gestión de sesiones para CouchDB con whitelist + auto-hash + recarga cada 5 min
-- Versión final: evita bloqueos en navegador, permite acceso anónimo, maneja chunked correctamente

local cjson = require "cjson.safe"
local http = require "resty.http"
local io = require "io"
local os = require "os"
local ngx = ngx
local string_match = string.match

-- Configuración: ajusta COUCHDB_URL según tu entorno Docker
local COUCHDB_URL = "http://127.0.0.1:23080"  -- ← Nombre del servicio de CouchDB en Docker
local WHITELIST_FILE = "conf/whitelist.json"
local LOG_FILE = "/usr/local/openresty/nginx/logs/session_audit.log"
local DEBUG_SALT = "cambia_esta_salt_por_una_larga_y_secreta_2025!@#$"
local CACHE_TTL = 300  -- 5 minutos

-- Función de log segura
local function log_to_file(level, message)
    local timestamp = os.date("%Y-%m-%d %H:%M:%S")
    local fd = io.open(LOG_FILE, "a")
    if fd then
        fd:write(string.format("%s [%s] %s\n", timestamp, level, message))
        fd:close()
    end
end

-- Validación de hash
local function looks_like_hash(s)
    if type(s) ~= "string" then return false end
    s = s:gsub("^%s+", ""):gsub("%s+$", "")
    if #s < 42 or #s > 44 then return false end
    return string_match(s, "^[a-zA-Z0-9+/]+$") ~= nil
end

-- Generación de hash
local function compute_debug_hash(password)
    local resty_sha256 = require "resty.sha256"
    local sha256 = resty_sha256:new()
    sha256:update(DEBUG_SALT .. password)
    return ngx.encode_base64(sha256:final(), true):lower()
end

-- Carga y cachea whitelist
local function get_cached_whitelist()
    local dict = ngx.shared.active_sessions
    local prefix = ngx.config.prefix()
    local filepath = prefix .. WHITELIST_FILE
    local now = ngx.time()
    local last_load = tonumber(dict:get("whitelist_last_load") or 0)

    if now - last_load > CACHE_TTL then
        local file = io.open(filepath, "r")
        if not file then
            dict:set("whitelist_last_load", now)
            return {}
        end
        local content = file:read("*a")
        file:close()

        local ok, whitelist = pcall(cjson.decode, content)
        if not ok or type(whitelist) ~= "table" then
            dict:set("whitelist_last_load", now)
            return {}
        end

        local changed = false
        local updated = {}
        for user, value in pairs(whitelist) do
            if type(value) == "string" and not looks_like_hash(value) then
                updated[user] = compute_debug_hash(value)
                changed = true
                log_to_file("INFO", "Convertido usuario " .. tostring(user) .. " a hash.")
            else
                updated[user] = value
            end
        end

        if changed then
            cjson.encode_escape_forward_slash(false)
            local new_content = cjson.encode(updated)
            local out = io.open(filepath, "w")
            if out then
                out:write(new_content)
                out:close()
                log_to_file("INFO", "whitelist.json actualizado con hashes.")
            end
            whitelist = updated
        end

        dict:set("whitelist_cache", cjson.encode(whitelist))
        dict:set("whitelist_last_load", now)
        if last_load > 0 then
            log_to_file("INFO", "whitelist.json recargado (cada 5 min).")
        end
        return whitelist
    else
        local cached = dict:get("whitelist_cache")
        if cached then
            local ok, data = pcall(cjson.decode, cached)
            if ok and type(data) == "table" then
                return data
            end
        end
        return {}
    end
end

-- Verificación de contraseña debug
local function verify_debug_password(username, debug_password)
    if not username or not debug_password or debug_password == "" then
        return false
    end
    local whitelist = get_cached_whitelist()
    local stored_hash = whitelist[username]
    if not stored_hash or not looks_like_hash(stored_hash) then
        return false
    end
    local computed = compute_debug_hash(debug_password)
    return computed == stored_hash
end

-- Obtener usuario por cookie (cache local)
local function get_user_by_cookie(cookie)
    if not cookie then return nil end
    local dict = ngx.shared.active_sessions
    local keys = dict:get_keys(0)
    for _, user in ipairs(keys) do
        if dict:get(user) == cookie then
            return user
        end
    end
    return nil
end

-- Validar cookie contra CouchDB
local function validate_cookie_and_get_user(cookie)
    if not cookie then return nil end
    local httpc = http.new()
    httpc:set_timeout(5000)
    local res, err = httpc:request_uri(COUCHDB_URL .. "/_session", {
        method = "GET",
        headers = { ["Cookie"] = "AuthSession=" .. cookie }
    })
    httpc:close()
    if res and res.status == 200 then
        local ok, data = pcall(cjson.decode, res.body)
        if ok and type(data) == "table" and data.userCtx and type(data.userCtx) == "table" then
            local name = data.userCtx.name
            if type(name) == "string" and name ~= "" then
                return name
            end
        end
    end
    return nil
end

-- === INICIO DEL MANEJADOR PRINCIPAL ===
local method = ngx.req.get_method()
local uri = ngx.var.uri
local cookie_header = ngx.var.http_cookie or ""
local auth_cookie = string_match(cookie_header, "AuthSession=([^;]+)")

if uri == "/_session" then
    local httpc = http.new()
    httpc:set_timeout(5000)

    if method == "POST" then
        ngx.req.read_body()
        local args, err = ngx.req.get_post_args()
        if not args or not args.name then
            ngx.status = 400
            ngx.say(cjson.encode({error = "Falta el campo 'name'"}))
            ngx.eof()
            return
        end

        local username = tostring(args.name)
        local password = tostring(args.password or "")
        local debug_password = tostring(args.debug_password or "")
        local couchdb_body = "name=" .. ngx.escape_uri(username) .. "&password=" .. ngx.escape_uri(password)

        local res, err = httpc:request_uri(COUCHDB_URL .. "/_session", {
            method = "POST",
            body = couchdb_body,
            headers = { ["Content-Type"] = "application/x-www-form-urlencoded" }
        })

        if not res then
            log_to_file("ERROR", "[LOGIN FAILED] Error al contactar CouchDB: " .. tostring(err))
            ngx.status = 502
            ngx.say("Bad Gateway")
            ngx.eof()
            return
        end

        if res.status == 200 then
            local set_cookie = res.headers["Set-Cookie"]
            local new_cookie = set_cookie and string_match(set_cookie, "AuthSession=([^;]+)")
            if not new_cookie then
                log_to_file("ERROR", "[LOGIN] No se obtuvo AuthSession de CouchDB")
                ngx.status = 500
                ngx.say("Internal Error")
                ngx.eof()
                return
            end

            local is_debug_user = false
            if debug_password ~= "" then
                if verify_debug_password(username, debug_password) then
                    is_debug_user = true
                else
                    log_to_file("WARNING", "[LOGIN] Usuario " .. tostring(username) .. " envió debug_password incorrecta.")
                end
            end

            local dict = ngx.shared.active_sessions
            if is_debug_user then
                log_to_file("INFO", "[LOGIN] Usuario DEBUG " .. tostring(username) .. " inició sesión.")
            else
                local old_cookie = dict:get(username)
                if old_cookie then
                    log_to_file("WARNING", "[LOGIN] Usuario " .. tostring(username) .. " reemplazó su sesión anterior.")
                end
                dict:set(username, new_cookie)
            end

            ngx.header["Set-Cookie"] = "AuthSession=" .. new_cookie .. "; HttpOnly; Path=/"
            ngx.status = 200
            ngx.print(res.body)
            ngx.eof()
        else
            log_to_file("ERROR", "[LOGIN FAILED] Usuario " .. tostring(username) .. " falló login. Status: " .. tostring(res.status))
            ngx.status = res.status
            ngx.print(res.body)
            ngx.eof()
        end

    elseif method == "DELETE" then
        if not auth_cookie then
            ngx.status = 400
            ngx.say(cjson.encode({error = "No cookie"}))
            ngx.eof()
            return
        end

        local dict = ngx.shared.active_sessions
        local user = get_user_by_cookie(auth_cookie)
        if user then
            dict:delete(user)
            log_to_file("INFO", "[LOGOUT] Usuario " .. tostring(user) .. " cerró sesión.")
        else
            log_to_file("WARNING", "[LOGOUT FAILED] Intento de logout con cookie inválida: " .. tostring(auth_cookie))
        end

        ngx.header["Set-Cookie"] = "AuthSession=; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/"
        ngx.status = 200
        ngx.say(cjson.encode({ok = true}))
        ngx.eof()

    elseif method == "GET" then
        local dict = ngx.shared.active_sessions
        local user = get_user_by_cookie(auth_cookie)
        if user then
            log_to_file("INFO", "[SESSION CHECK] Usuario normal " .. tostring(user) .. " validó su sesión.")
            local res, err = httpc:request_uri(COUCHDB_URL .. "/_session", {
                method = "GET",
                headers = { ["Cookie"] = "AuthSession=" .. auth_cookie }
            })
            ngx.status = res.status
            ngx.print(res.body)
            ngx.eof()
            return
        end

        local couch_user = validate_cookie_and_get_user(auth_cookie)
        if not couch_user then
            log_to_file("WARNING", "[SESSION CHECK] Cookie inválida: " .. tostring(auth_cookie or "nil"))
            ngx.status = 401
            ngx.say(cjson.encode({ok = false, error = "Sesión inválida"}))
            ngx.eof()
            return
        end

        local whitelist = get_cached_whitelist()
        if whitelist[couch_user] and looks_like_hash(whitelist[couch_user]) then
            log_to_file("INFO", "[SESSION CHECK] Usuario DEBUG " .. tostring(couch_user) .. " validó su sesión.")
            local res, err = httpc:request_uri(COUCHDB_URL .. "/_session", {
                method = "GET",
                headers = { ["Cookie"] = "AuthSession=" .. auth_cookie }
            })
            ngx.status = res.status
            ngx.print(res.body)
            ngx.eof()
        else
            log_to_file("WARNING", "[SESSION CHECK] Usuario no autorizado: " .. tostring(couch_user))
            ngx.status = 401
            ngx.say(cjson.encode({ok = false, error = "Sesión no autorizada"}))
            ngx.eof()
        end

    else
        ngx.status = 405
        ngx.say("Method not allowed")
        ngx.eof()
    end

else
    -- === ACCESO A /, /_utils, /db, etc. ===

    if auth_cookie and auth_cookie ~= "" then
        local dict = ngx.shared.active_sessions
        local user = get_user_by_cookie(auth_cookie)
        if user then
            log_to_file("INFO", "[ACCESS] Usuario normal " .. tostring(user) .. " accedió a " .. uri)
        else
            local couch_user = validate_cookie_and_get_user(auth_cookie)
            if not couch_user then
                log_to_file("WARNING", "[ACCESS DENIED] Cookie inválida en " .. uri)
                ngx.status = 401
                ngx.say(cjson.encode({error = "Sesión inválida"}))
                ngx.eof()
                return
            end

            local whitelist = get_cached_whitelist()
            if whitelist[couch_user] and looks_like_hash(whitelist[couch_user]) then
                log_to_file("INFO", "[ACCESS] Usuario DEBUG " .. tostring(couch_user) .. " accedió a " .. uri)
            else
                log_to_file("WARNING", "[ACCESS DENIED] Usuario no autorizado: " .. tostring(couch_user))
                ngx.status = 401
                ngx.say(cjson.encode({error = "Sesión no autorizada"}))
                ngx.eof()
                return
            end
        end
    else
        log_to_file("INFO", "[ACCESS] Acceso anónimo a " .. uri)
    end

    -- Solo leer cuerpo si es necesario (evita bloqueo en GET/HEAD)
    local body = nil
    if method == "POST" or method == "PUT" or method == "PATCH" then
        ngx.req.read_body()
        body = ngx.req.get_body_data()
    end

    local headers = {}
    for k, v in pairs(ngx.req.get_headers()) do
        if k ~= "host" and k ~= "cookie" then
            headers[k] = v
        end
    end
    if auth_cookie and auth_cookie ~= "" then
        headers["Cookie"] = "AuthSession=" .. auth_cookie
    end

    local httpc = http.new()
    httpc:set_timeout(5000)
    local res, err = httpc:request_uri(COUCHDB_URL .. uri, {
        method = method,
        body = body,
        headers = headers
    })
    httpc:close()

    if not res then
        log_to_file("ERROR", "[PROXY ERROR] Falló conexión a CouchDB: " .. tostring(err))
        ngx.status = 502
        ngx.say("Bad Gateway")
        ngx.eof()
        return
    end

    -- Establecer estado
    ngx.status = res.status

    -- Copiar headers, pero eliminar aquellos que interfieren con el cierre
    for k, v in pairs(res.headers) do
        if k ~= "set-cookie" and k ~= "transfer-encoding" and k ~= "connection" then
            ngx.header[k] = v
        end
    end

    -- Forzar cierre de conexión para evitar que el navegador espere chunks
    ngx.header["Transfer-Encoding"] = nil
    ngx.header["Connection"] = "close"

    -- Enviar cuerpo si existe
    if res.body and res.body ~= "" then
        ngx.print(res.body)
    end

    -- ✅ Cerrar conexión explícitamente
    ngx.eof()
end
